// Includes
#include "stdafx.h"
#include <windows.h>
#include <conio.h>
#include <strsafe.h>
#include <setupapi.h>
#include <winusb.h>
#include <stdio.h>
#include <conio.h>
#include <tchar.h>
// Include WinUSB headers
#include <winusb.h>
#include <Setupapi.h>

// CK-USB-04a interface GUID
const GUID CK_USB_04a = { 0xb379444d, 0x2093, 0x41de, 0xb7, 0xab, 0x80, 0xa8, 0xa3, 0x0d, 0xcf, 0x38 };

// CK-USB-04a Custom protocol definitions
#define CK_CMD_TXRX_DATA			0x01
#define CK_CMD_READ_VERSION         0xF0 
#define CK_CMD_READ_ID              0xF8 
#define CK_CMD_BLINK                0xFB 
#define CK_MAX_DLEN					60
#define PTYPE_WR					0x80
#define PTYPE_RD					0x00
#define SPI_CMD_DATA_RW				0xf0
#define SPI_CHECK					0x00

// PIPE ID struct
struct PIPE_ID
{
  UCHAR  PipeInId;
  UCHAR  PipeOutId;
};

/*
//-----------------------------------------------------------------------------
// GetDeviceHandle()
//
// Parameters:
//        guidDeviceInterface: DEVICE GUID defined in WinUSB inf file
//        hDeviceHandle		 : device handle returned
//
// Return Values:
//        true : success
//        false: fail
//
// Remarks:
//        Function to create file handle for USB device
//-----------------------------------------------------------------------------
*/
BOOL GetDeviceHandle(GUID guidDeviceInterface, PHANDLE hDeviceHandle)
{
	BOOL bResult = TRUE;
	HDEVINFO hDeviceInfo;
	SP_DEVINFO_DATA DeviceInfoData;
	SP_DEVICE_INTERFACE_DATA deviceInterfaceData;
	PSP_DEVICE_INTERFACE_DETAIL_DATA pInterfaceDetailData = NULL;
	ULONG requiredLength = 0;
	LPTSTR lpDevicePath = NULL;
	DWORD index = 0;

	if (guidDeviceInterface == GUID_NULL) {
		return FALSE;
	}

	// Get information about all the installed devices for the specified
	// device interface class.
	hDeviceInfo = SetupDiGetClassDevs(
		&guidDeviceInterface,
		NULL,
		NULL,
		DIGCF_PRESENT | DIGCF_DEVICEINTERFACE);

	if (hDeviceInfo == INVALID_HANDLE_VALUE) {

		printf("Error: %d - %s\r\n", GetLastError(), "No device installed");
		goto done;
	}

	//Enumerate all the device interfaces in the device information set.
	DeviceInfoData.cbSize = sizeof(SP_DEVINFO_DATA);

	for (index = 0; SetupDiEnumDeviceInfo(hDeviceInfo, index, &DeviceInfoData); index++) {
		//Reset for this iteration
		if (lpDevicePath) {
			LocalFree(lpDevicePath);
		}

		if (pInterfaceDetailData) {
			LocalFree(pInterfaceDetailData);
		}

		deviceInterfaceData.cbSize = sizeof(SP_INTERFACE_DEVICE_DATA);

		//Get information about the device interface.
		bResult = SetupDiEnumDeviceInterfaces(
			hDeviceInfo,
			&DeviceInfoData,
			&guidDeviceInterface,
			index,
			&deviceInterfaceData);

		// Check if last item
		if (GetLastError() == ERROR_NO_MORE_ITEMS) {
			break;
		}

		bResult = SetupDiEnumDeviceInterfaces(
			hDeviceInfo,
			&DeviceInfoData,
			&guidDeviceInterface,
			index,
			&deviceInterfaceData);

		// Check if last item
		if (GetLastError() == ERROR_NO_MORE_ITEMS) {
			break;
		}

		//Check for some other error
		if (!bResult) {
			printf("Error SetupDiEnumDeviceInterfaces: %d.\n", GetLastError());
			goto done;
		}

		//Interface data is returned in SP_DEVICE_INTERFACE_DETAIL_DATA
		//which we need to allocate, so we have to call this function twice.
		//First to get the size so that we know how much to allocate
		//Second, the actual call with the allocated buffer

		bResult = SetupDiGetDeviceInterfaceDetail(
			hDeviceInfo,
			&deviceInterfaceData,
			NULL, 0,
			&requiredLength,
			NULL);

		//Check for some other error
		if (!bResult) {
			if ((ERROR_INSUFFICIENT_BUFFER == GetLastError()) && (requiredLength > 0)) {
				//we got the size, allocate buffer
				pInterfaceDetailData = (PSP_DEVICE_INTERFACE_DETAIL_DATA)LocalAlloc(LPTR, requiredLength);

				if (!pInterfaceDetailData) {
					// ERROR 
					printf("Error allocating memory for the device detail buffer.\n");
					goto done;
				}
			}
			else {
				printf("Error SetupDiEnumDeviceInterfaces: %d.\n", GetLastError());
				goto done;
			}
		}

		//get the interface detailed data
		pInterfaceDetailData->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);

		//Now call it with the correct size and allocated buffer
		bResult = SetupDiGetDeviceInterfaceDetail(
			hDeviceInfo,
			&deviceInterfaceData,
			pInterfaceDetailData,
			requiredLength,
			NULL,
			&DeviceInfoData);

		//Check for some other error
		if (!bResult) {
			printf("Error SetupDiGetDeviceInterfaceDetail: %d.\n", GetLastError());
			goto done;
		}

		//copy device path
		size_t nLength = wcslen(pInterfaceDetailData->DevicePath) + 1;
		lpDevicePath = (TCHAR *)LocalAlloc(LPTR, nLength * sizeof(TCHAR));
		StringCchCopy(lpDevicePath, nLength, pInterfaceDetailData->DevicePath);
		lpDevicePath[nLength - 1] = 0;

		printf("Device path:  %s\n", lpDevicePath);
	}

	if (!lpDevicePath) {
		//Error.
		printf("Error: %d - %s\r\n", GetLastError(), "No device installed");
		goto done;
	}

	//Open the device
	*hDeviceHandle = CreateFile(
		lpDevicePath,
		GENERIC_READ | GENERIC_WRITE,
		FILE_SHARE_READ | FILE_SHARE_WRITE,
		NULL,
		OPEN_EXISTING,
		FILE_FLAG_OVERLAPPED,
		NULL);

	if (*hDeviceHandle == INVALID_HANDLE_VALUE) {
		//Error.
		printf("Error: %d - %s\r\n", GetLastError(), "Error openenig the device");
		goto done;
	}

done:
	LocalFree(lpDevicePath);
	LocalFree(pInterfaceDetailData);
	bResult = SetupDiDestroyDeviceInfoList(hDeviceInfo);

	return bResult;
} // End of GetDeviceHandle()


/*
//-----------------------------------------------------------------------------
// GetWinUSBHandle()
//
// Parameters:
//        hDeviceHandle  : device handle created for the USB device
//        phWinUSBHandle : WinUSB Interface handle returned
//
// Return Values:
//        true : success
//        false: fail
//
// Remarks:
//        Function to get WinUSB Interface Handle for the device
//-----------------------------------------------------------------------------
*/
BOOL GetWinUSBHandle(HANDLE hDeviceHandle, PWINUSB_INTERFACE_HANDLE phWinUSBHandle)
{
	if (hDeviceHandle == INVALID_HANDLE_VALUE) {
		return FALSE;
	}

	BOOL bResult = WinUsb_Initialize(hDeviceHandle, phWinUSBHandle);

	if (!bResult) {
		//Error.
		printf("WinUsb_Initialize Error %d.", GetLastError());
		return FALSE;
	}

	return bResult;
} // End of GetWinUSBHandle()

/*
//-----------------------------------------------------------------------------
// GetUSBDeviceSpeed()
//
// Parameters:
//        hDeviceHandle  : WinUSB Interface Handle
//        pDeviceSpeed   : Device Speed returned
//
// Return Values:
//        true : success
//        false: fail
//
// Remarks:
//        Function to get device speed
//-----------------------------------------------------------------------------
*/
BOOL GetUSBDeviceSpeed(WINUSB_INTERFACE_HANDLE hDeviceHandle, UCHAR* pDeviceSpeed)
{
	if (!pDeviceSpeed || hDeviceHandle == INVALID_HANDLE_VALUE) {
		return FALSE;
	}

	BOOL bResult = TRUE;

	ULONG length = sizeof(UCHAR);

	bResult = WinUsb_QueryDeviceInformation(hDeviceHandle, DEVICE_SPEED, &length, pDeviceSpeed);
	if (!bResult) {
		printf("Error getting device speed: %d.\n", GetLastError());
		goto done;
	}

	if (*pDeviceSpeed == LowSpeed) {
		printf("Device speed: %d (Low speed).\n", *pDeviceSpeed);
		goto done;
	}

	if (*pDeviceSpeed == FullSpeed) {
		printf("Device speed: %d (Full speed).\n", *pDeviceSpeed);
		goto done;
	}

	if (*pDeviceSpeed == HighSpeed) {
		printf("Device speed: %d (High speed).\n", *pDeviceSpeed);
		goto done;
	}

done:
	return bResult;
} // End of GetUSBDeviceSpeed()

/*
//-----------------------------------------------------------------------------
// QueryDeviceEndpoints()
//
// Parameters:
//        hDeviceHandle  : WinUSB Interface Handle
//        pipeid		 : Pipe ID returned
//
// Return Values:
//        true : success
//        false: fail
//
// Remarks:
//        Function to check end points and get pipe ID
//-----------------------------------------------------------------------------
*/
BOOL QueryDeviceEndpoints(WINUSB_INTERFACE_HANDLE hDeviceHandle, PIPE_ID* pipeid)
{
	if (hDeviceHandle == INVALID_HANDLE_VALUE) {
		return FALSE;
	}

	BOOL bResult = TRUE;

	USB_INTERFACE_DESCRIPTOR InterfaceDescriptor;
	ZeroMemory(&InterfaceDescriptor, sizeof(USB_INTERFACE_DESCRIPTOR));

	WINUSB_PIPE_INFORMATION  Pipe;
	ZeroMemory(&Pipe, sizeof(WINUSB_PIPE_INFORMATION));

	bResult = WinUsb_QueryInterfaceSettings(hDeviceHandle, 0, &InterfaceDescriptor);

	if (bResult) {
		for (int index = 0; index < InterfaceDescriptor.bNumEndpoints; index++) {
			bResult = WinUsb_QueryPipe(hDeviceHandle, 0, index, &Pipe);

			if (bResult) {
				if (Pipe.PipeType == UsbdPipeTypeControl) {
					printf("Endpoint index: %d Pipe type: Control Pipe ID: %d.\n", index, Pipe.PipeType, Pipe.PipeId);
				}

				if (Pipe.PipeType == UsbdPipeTypeIsochronous) {
					printf("Endpoint index: %d Pipe type: Isochronous Pipe ID: %d.\n", index, Pipe.PipeType, Pipe.PipeId);
				}

				if (Pipe.PipeType == UsbdPipeTypeBulk) {

					if (USB_ENDPOINT_DIRECTION_IN(Pipe.PipeId)) {
						printf("Endpoint index: %d Pipe type: Bulk IN Pipe ID: %d.\n", index, Pipe.PipeType, Pipe.PipeId);
						pipeid->PipeInId = Pipe.PipeId;
					}

					if (USB_ENDPOINT_DIRECTION_OUT(Pipe.PipeId)) {
						printf("Endpoint index: %d Pipe type: Bulk OUT Pipe ID: %d.\n", index, Pipe.PipeType, Pipe.PipeId);
						pipeid->PipeOutId = Pipe.PipeId;
					}

				}

				if (Pipe.PipeType == UsbdPipeTypeInterrupt) {
					printf("Endpoint index: %d Pipe type: Interrupt Pipe ID: %d.\n", index, Pipe.PipeType, Pipe.PipeId);
				}
			}
			else {
				continue;
			}
		}
	}

	//done:
	return bResult;
} // End of QueryDeviceEndpoints()


/*
//-----------------------------------------------------------------------------
// WriteToBulkEndpoint()
//
// Parameters:
//        hDeviceHandle  : WinUSB Interface Handle
//        pID			 : pointer to Pipe ID
//		  pcbWritten     : number of bytes actually written to the OUT endpoint
//		  szBuffer       : data buffer to be written
//		  cbSize         : size of the data buffer to be written
//
// Return Values:
//        true : success
//        false: fail
//
// Remarks:
//        Function to write data to OUT bulk endpoint
//-----------------------------------------------------------------------------
*/
BOOL WriteToBulkEndpoint(WINUSB_INTERFACE_HANDLE hDeviceHandle, UCHAR* pID, ULONG* pcbWritten, UCHAR *szBuffer, ULONG cbSize)
{
	if (hDeviceHandle == INVALID_HANDLE_VALUE || !pID || !pcbWritten) {
		return FALSE;
	}

	BOOL bResult = TRUE;
	ULONG cbSent = 0;
	bResult = WinUsb_WritePipe(hDeviceHandle, *pID, szBuffer, cbSize, &cbSent, 0);
	*pcbWritten = cbSent;
	return bResult;
} // End of WriteToBulkEndpoint()

/*
//-----------------------------------------------------------------------------
// ReadFromBulkEndpoint()
//
// Parameters:
//        hDeviceHandle  : WinUSB Interface Handle
//        pID			 : pointer to Pipe ID
//		  szBuffer       : data buffer to be filled
//		  cbSize         : size of the data buffer to be filled
//
// Return Values:
//        true : success
//        false: fail
//
// Remarks:
//        Function to read data from IN bulk endpoint
//-----------------------------------------------------------------------------
*/
BOOL ReadFromBulkEndpoint(WINUSB_INTERFACE_HANDLE hDeviceHandle, UCHAR* pID, UCHAR* szBuffer, ULONG cbSize)
{
	if (hDeviceHandle == INVALID_HANDLE_VALUE) {
		return FALSE;
	}

	BOOL bResult = TRUE;
	ULONG cbRead = 0;
	bResult = WinUsb_ReadPipe(hDeviceHandle, *pID, szBuffer, cbSize, &cbRead, 0);
	return bResult;
} // End of ReadFromBulkEndpoint()

//-------------------------
// Get TR module SPI status
//-------------------------
byte spiGetStatus(WINUSB_INTERFACE_HANDLE hDeviceHandle, int timeout)
{
	byte buff[16], spiStatus;
	ULONG written = 0;
	ULONG read = 0;

	while (timeout)
	{
		buff[0] = CK_CMD_TXRX_DATA; //CK command
		buff[1] = SPI_CHECK; //Get Status
		buff[2] = SPI_CHECK; //Get Status
		if (WinUsb_WritePipe(hDeviceHandle, 0x01, buff, 3, &written, NULL) == FALSE)
		{
			printf("Could write to the device\r\n");
			return FALSE;
		}
		if (WinUsb_ReadPipe(hDeviceHandle, 0x81, buff, 2, &read, NULL) == FALSE)
		{
			printf("Could read from the device\r\n");
			return FALSE;
		}
		// Any data available in bufferCOM ?
		spiStatus = buff[1];
		if (spiStatus > 63 && spiStatus < 128)
		{
			if (spiStatus != 64)
				spiStatus -= 64;
			return spiStatus;
		}
		Sleep(1);
		timeout--;
	}

	// SPI not ready
	return spiStatus;
}

//-----------------------------
// Communication with TR-Module
//-----------------------------
BOOL spiTransfer(WINUSB_INTERFACE_HANDLE hDeviceHandle, BOOL WR, byte *DLEN, byte *spiBuffer) {

	byte outBuff[128];
	byte inBuff[128];
	byte inBuff1[128];
	byte SPIDLEN = 0;
	bool splitPacket = FALSE;
	ULONG written = 0;
	ULONG read = 0, read1 = 0;
	int len = 0, crcOffset = 0;
	int toWrite = 0, toRead = 0;
	byte PTYPE;

	//Clear buffers
	memset(outBuff, 0, sizeof(outBuff));
	memset(inBuff, 0, sizeof(inBuff));
	memset(inBuff1, 0, sizeof(inBuff1));

	// Write operation ?
	if (WR)
	{
		// Yes, set PTYPE for write, copy user data to outBuff
		PTYPE = PTYPE_WR;
		SPIDLEN = *DLEN;
		memcpy(&outBuff[3], spiBuffer, *DLEN);
	}
	else
	{
		// Get TR module SPI status
		PTYPE = PTYPE_RD;
		SPIDLEN = spiGetStatus(hDeviceHandle, 500);
		if (SPIDLEN == 0 || SPIDLEN > 64)
			return FALSE;
	}

	// Prepare SPI packet	
	PTYPE |= (byte)SPIDLEN;
	byte crc = (byte)(0x5f ^ 0xf0 ^ PTYPE);
	outBuff[0] = CK_CMD_TXRX_DATA;
	outBuff[1] = SPI_CMD_DATA_RW;
	outBuff[2] = PTYPE;

	//Copy user data
	if (SPIDLEN > CK_MAX_DLEN)
	{
		len = 61;
		crcOffset = 4;
		splitPacket = TRUE;
	}
	else
	{
		crcOffset = 3;
		len = SPIDLEN;
		splitPacket = FALSE;
	}

	toWrite = SPIDLEN + 4;
	if (splitPacket)
	{
		//Next part of packet must start with CK command 0x01
		outBuff[64] = 0x01;
		//Copy the rest of user data to outBuff
		memcpy(&outBuff[65], &spiBuffer[61], SPIDLEN - len);
		toWrite = 64;
	}
	toRead = toWrite - 1;

	int j = SPIDLEN + 3;
	//Calculate and put CRCM
	for (int i = 3; i < j; i++)
	{
		//CK command is excluded from CRC
		if (i == 64)
		{
			j++;
			continue;
		}
		crc ^= outBuff[i];
	}
	outBuff[crcOffset + SPIDLEN] = crc;

	//Send packet, read response		
	if (WinUsb_WritePipe(hDeviceHandle, 0x01, outBuff, toWrite, &written, NULL) == FALSE)
	{
		printf("Could write to the device\r\n");
		return FALSE;
	}
	if (WinUsb_ReadPipe(hDeviceHandle, 0x81, inBuff, toRead, &read, NULL) == FALSE)
	{
		printf("Could read from the device\r\n");
		return FALSE;
	}
	if (splitPacket)
	{
		//The second part
		byte tempBuff[64];
		toWrite = SPIDLEN + 4 - 64 + 1;
		toRead = toWrite - 1;
		memcpy(tempBuff, &outBuff[64], SPIDLEN);
		if (WinUsb_WritePipe(hDeviceHandle, 0x01, tempBuff, toWrite, &written, NULL) == FALSE)
		{
			printf("Could write to the device\r\n");
			return FALSE;
		}
		if (WinUsb_ReadPipe(hDeviceHandle, 0x81, tempBuff, toRead, &read1, NULL) == FALSE)
		{
			printf("Could read from the device\r\n");
			return FALSE;
		}
		memcpy(&inBuff[read], tempBuff, read1);
	}

	// Check CRCS
	crc = (byte)(PTYPE ^ 0x5f);
	for (byte i = 0; i < SPIDLEN + 1; i++)
		crc ^= inBuff[i + 2];
	if (crc == 0x00)
	{
		if (WR == FALSE)
		{
			memcpy(spiBuffer, &inBuff[2], SPIDLEN);
		}
		*DLEN = SPIDLEN;
		return TRUE;
	}
	else
	{
		printf("CRCS doesn't match\r\n");
		return FALSE;
	}
}

//-----
// Main
//-----
int _tmain(int argc, _TCHAR* argv[])
{
	UCHAR buffer[128];
	GUID guidDeviceInterface = CK_USB_04a;
	BOOL bResult = TRUE;
	PIPE_ID PipeID;
	HANDLE hDeviceHandle = INVALID_HANDLE_VALUE;
	WINUSB_INTERFACE_HANDLE hWinUSBHandle = INVALID_HANDLE_VALUE;
	UCHAR DeviceSpeed;
	UCHAR cbSize = 0;
	ULONG read, written;

	// Get handle, speed, pipe information
	bResult = GetDeviceHandle(guidDeviceInterface, &hDeviceHandle);
	if (!bResult) {
		goto done;
	}
	bResult = GetWinUSBHandle(hDeviceHandle, &hWinUSBHandle);
	if (!bResult) {
		goto done;

	}
	bResult = GetUSBDeviceSpeed(hWinUSBHandle, &DeviceSpeed);
	if (!bResult) {
		goto done;
	}
	bResult = QueryDeviceEndpoints(hWinUSBHandle, &PipeID);
	if (!bResult) {
		goto done;
	}

	system("mode CON: COLS=120");

	while (1) {

		// Menu	
		system("cls");
		printf("1. Press 1 to read CK-USB-04a ID\r\n");
		printf("2. Press 2 to get CK-USB-04a LED1 pulsing\r\n");
		printf("3. Press 3 to send data to TR module\r\n");
		printf("4. Press E to exit application\r\n");
		UCHAR key = _getch();
		system("cls");
		switch (key)
		{
			// Read CK ID
		case '1':
			// Read ID
			buffer[0] = CK_CMD_READ_ID;
			cbSize = 1;
			if (WinUsb_WritePipe(hWinUSBHandle, PipeID.PipeOutId, buffer, 1, &written, NULL) == FALSE)
			{
				printf("Could write to the device\r\n");
				break;
			}
			if (WinUsb_ReadPipe(hWinUSBHandle, PipeID.PipeInId, buffer, 5, &read, NULL) == FALSE)
			{
				printf("Could read from the device\r\n");
				break;
			}
			printf("CK-USB-04a: %02X%02X%02X%02X, ", buffer[1], buffer[2], buffer[3], buffer[4]);
			// CK_CMD_READ_VERSION
			buffer[0] = CK_CMD_READ_VERSION;
			cbSize = 1;
			if (WinUsb_WritePipe(hWinUSBHandle, PipeID.PipeOutId, buffer, 1, &written, NULL) == FALSE)
			{
				printf("Could write to the device\r\n");
				break;
			}
			if (WinUsb_ReadPipe(hWinUSBHandle, PipeID.PipeInId, buffer, 3, &read, NULL) == FALSE)
			{
				printf("Could read from the device\r\n");
				break;
			}
			printf("FW: v%x.%02x\r\n", buffer[1], buffer[2]);
			break;

			// Pulse CK LED1
		case '2':
			buffer[0] = CK_CMD_BLINK;
			cbSize = 1;
			if (WinUsb_WritePipe(hWinUSBHandle, PipeID.PipeOutId, buffer, 1, &written, NULL) == FALSE)
			{
				printf("Could write to the device\r\n");
				break;
			}
			break;

			// Send data to TR module - this example assumes application E07-SPI.c is loaded in TR module
		case '3':
			cbSize = 1;			// Send 1 byte	
			//buffer[0] = '3';	// '3' - LEDR flashes 3x
			//buffer[0] = '2';	// '2' - LEDR flashes 3x
			//buffer[0] = '1';	// '1' - LEDR flashes 3x
			buffer[0] = 'i';	// 'i' - TR module sends response '0123456789'

			printf("TX: ");
			for ( int i = 0; i < cbSize; i++ )
			{
				printf( "%02X.", buffer[i] );
			}
			printf("\r\n");
			if (spiTransfer(hWinUSBHandle, TRUE, &cbSize, buffer) == FALSE)
				break;
			memset(buffer, 0, sizeof(buffer));

			cbSize = 0;
			if (spiTransfer(hWinUSBHandle, FALSE, &cbSize, buffer) == FALSE)
				break;
			printf("\r\nRX: ");
			for (int i = 0; i < cbSize; i++)
			{
				printf("%02X.", buffer[i]);
			}
			break;

			// Exit
		case 'E':
		case 'e':
			goto EXIT;

		}
		printf("\r\n\r\nPress any key...");
		_getch();
	}

done:
	_getch();
EXIT:
	if (hWinUSBHandle != INVALID_HANDLE_VALUE)
		CloseHandle(hDeviceHandle);
	if (hWinUSBHandle != INVALID_HANDLE_VALUE)
		WinUsb_Free(hWinUSBHandle);
	return 0;
}

